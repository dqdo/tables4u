import mysql from 'mysql'

export const handler = async (event) => {
// get credentials from the db_access layer (loaded separately via AWS console)
// Make sure to delete this when copy and pasting to VScode or React Application BEFORE committing.
  var pool = mysql.createPool({
    host: "ozuma-database.cfmmgqa4yqlg.us-east-2.rds.amazonaws.com",
    user: "restaurantAdmin",
    password: "rxedF5!hgs",
    database: "tables4u"
  })
    
const editRestaurantName = (restaurant_id, name, newName) => {
    return new Promise((resolve, reject) => {
        const query = `
            SELECT * FROM restaurants WHERE id = restaurant_id
            
            UPDATE restaurants
            SET restaurant_name = 'newName'
            WHERE id = restaurant_id
            `;
        const params = [restaurant_id, name, newName];

        pool.query(query, params, (error, results) => {
            if (error) {
                return reject(error);
            }
            resolve(results);
        });
    });
};


  let response
  try{
    await editRestaurantName(event.restaurant_id, event.name, event.newName)

    response = {
        statusCode: 200,
        result: {
            oldname: event.name,
            newName: event.newName,
            restaurantID: event.restaurant_id
        }
    };
  } catch (error){
    response = {
        statusCode: 400,
        error: "Failed to update restaurant.",
        details: error.message
      };
  }
  
  pool.end()  

  return response;
}


