import mysql from 'mysql'

export const handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
    host: "ozuma-database.cfmmgqa4yqlg.us-east-2.rds.amazonaws.com",
    user: "restaurantAdmin",
    password: "rxedF5!hgs",
    database: "tables4u"
})
  
  let CountConstants = () => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT COUNT(*) AS `num` FROM Constants;", [], (error, value) => {
            if (error) { return reject(error); }
            // turns into array containing single value [ { num: 13 } ]
            let output = JSON.parse(JSON.stringify(value))
            
            // return first entry and grab its 'num' attribute
            return resolve(output[0].num);
        })
    })
}



let CreateConstant = (name, location) => {
    return new Promise((resolve, reject) => {
        pool.query("INSERT INTO RESTAURANTS (restaurant_name, restaurant_location) VALUES (?, ?) ON DUPLICATE KEY UPDATE value=?;", [name, value, value], (error, rows) => {
            if (error) { return reject(error); }
            return resolve(rows);
        })
    })
}

const numbers = await CountConstants()
let response;
if (numbers > 30) {
   response = {
    statusCode: 400,
    error: "Too many constants defined."
  }
} else {

    // NOTE: what if fails?
    const all_result = await CreateConstant(event.name, event.location)
    
    response = {
      statusCode: 200,
      result: {
        "name" : event.name,
        "location" : event.location
      }
    }
  }

pool.end()     // close DB connections

return response;
}