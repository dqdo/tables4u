import mysql from 'mysql'

export const handler = async (event) => {
// get credentials from the db_access layer (loaded separately via AWS console)
// Make sure to delete this when copy and pasting to VScode or React Application BEFORE committing.
  var pool = mysql.createPool({
    host: "ozuma-database.cfmmgqa4yqlg.us-east-2.rds.amazonaws.com",
    user: "restaurantAdmin",
    password: "rxedF5!hgs",
    database: "tables4u"
  })
    
const editRestaurantTableSeatNumber = (restaurant_id, seatNumber) => {
    return new Promise((resolve, reject) => {
        const query = `
            SELECT * FROM restaurants_tables 
            WHERE restaurant_id = ?

            `;
        const params = [restaurant_id];

        pool.query(query, params, (error, results) => {
            if (error) {
                return reject(error);
            }
            resolve(results);
        })
      
        const updateQuery = `
        
        UPDATE restaurants_tables
        SET seats = ?
        WHERE restaurant_id = ?
        `;
        
        const updateParams = [seatNumber, restaurant_id];

        pool.query(updateQuery,updateParams, (updateError, updateResults) => {
          if (updateError) {
            return reject (updateError);
          }
          
          resolve(updateResults)

        });
      });
    };


  let response
  try{
    await editRestaurantTableSeatNumber(event.restaurant_id, event.seatNumber)

    response = {
        statusCode: 200,
        result: {
            seatNumber : event.seatNumber,
            restaurantID: event.restaurant_id
        }
    };
  } catch (error){
    response = {
        statusCode: 400,
        error: "Failed to update restaurant.",
        details: error.message
      };
  }
  
  pool.end()  

  return response;
}


